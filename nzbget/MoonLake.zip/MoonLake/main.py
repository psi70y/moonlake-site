#!/usr/bin/env python3
# MoonLake extension for NZBGet: tells MoonLake's notification relay about downloads, so the
# MoonLake app can notify you and show them on your Lock Screen. Standard library only.
#
# Queue events: NZB_ADDED, NZB_DELETED. Post-processing: the download's final status.
# Sends the name, category, status and how many downloads are left, nothing else.

import base64
import json
import os
import sys
import urllib.request

POSTPROCESS_SUCCESS, POSTPROCESS_ERROR, POSTPROCESS_NONE = 93, 94, 95
COMMAND_SUCCESS, COMMAND_ERROR = 93, 94

env = os.environ.get
addresses = (env("NZBPO_ADDRESSES") or env("NZBPO_Addresses") or "").split()
command = env("NZBCP_COMMAND")
event = env("NZBNA_EVENT")
is_post_processing = env("NZBPP_NZBNAME") is not None


def remaining(excluding):
    """How many downloads are left in the queue, not counting this one (or -1 if unknown)."""
    try:
        host = env("NZBOP_CONTROLIP") or "127.0.0.1"
        if host in ("0.0.0.0", "::"):
            host = "127.0.0.1"
        url = "http://%s:%s/jsonrpc/listgroups" % (host, env("NZBOP_CONTROLPORT") or "6789")
        request = urllib.request.Request(url)
        login = "%s:%s" % (env("NZBOP_CONTROLUSERNAME") or "", env("NZBOP_CONTROLPASSWORD") or "")
        request.add_header("Authorization", "Basic " + base64.b64encode(login.encode()).decode())
        with urllib.request.urlopen(request, timeout=10) as response:
            groups = json.load(response).get("result", [])
        # Jobs still downloading or waiting; ones post-processing have finished downloading.
        waiting = [g for g in groups if g.get("Status") in ("QUEUED", "PAUSED", "DOWNLOADING", "FETCHING")]
        return len([g for g in waiting if str(g.get("NZBID")) != str(excluding)])
    except Exception:
        return -1


def send(payload):
    """Posts to every connected device's address. Returns whether any accepted it."""
    body = json.dumps(payload).encode()
    delivered = False
    for address in addresses:
        try:
            request = urllib.request.Request(address, data=body, headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(request, timeout=15):
                delivered = True
        except Exception as error:
            print("[WARNING] MoonLake: couldn't reach the relay: %s" % error)
    return delivered


if command is not None:
    if command != "Test":
        print("[ERROR] Unknown command " + command)
        sys.exit(COMMAND_ERROR)
    if not addresses:
        print("[ERROR] No devices connected. In MoonLake, open Settings → Notifications and tap Connect.")
        sys.exit(COMMAND_ERROR)
    ok = send({"event": "test"})
    print("[INFO] Test sent." if ok else "[ERROR] The relay couldn't be reached.")
    sys.exit(COMMAND_SUCCESS if ok else COMMAND_ERROR)

if not addresses:
    # Installed but not connected from the app: nothing to do.
    sys.exit(POSTPROCESS_NONE if is_post_processing else 0)

if is_post_processing:
    send({
        "event": "done",
        "name": env("NZBPP_NZBNAME") or "",
        "category": env("NZBPP_CATEGORY") or "",
        "status": env("NZBPP_STATUS") or "",
        "totalStatus": env("NZBPP_TOTALSTATUS") or "",
        "remaining": remaining(env("NZBPP_NZBID")),
    })
    # A notification isn't part of the download's processing, so it never fails it.
    sys.exit(POSTPROCESS_SUCCESS)

if event in ("NZB_ADDED", "NZB_DELETED"):
    send({
        "event": "added" if event == "NZB_ADDED" else "deleted",
        "name": env("NZBNA_NZBNAME") or "",
        "category": env("NZBNA_CATEGORY") or "",
        "deleteStatus": env("NZBNA_DELETESTATUS") or "",
        "remaining": remaining(env("NZBNA_NZBID")),
    })
sys.exit(0)
